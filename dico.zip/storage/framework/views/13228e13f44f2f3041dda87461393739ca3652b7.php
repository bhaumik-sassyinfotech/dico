
<title>DICO - User</title>
<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('err_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('err_msg')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('user.index')); ?>">User</a></li>
                    <li class="active">Update User</li>
                </ol>
                <h1>User</h1>
                <?php /*<div>
                <div class="col-md-6 pull-right nopadding"><p style="float:right;"><a href="{{ url('/home') }}">Dashboard</a> > <a href="{{ route('user.index') }}">User</a> > Update User</p></div>
            </div>*/?>
                <div class="options">
                    <div class="btn-toolbar">
                        <?php
                        if(!empty($user->following) && count($user->following) > 0) {
                        if($user->following[ 0 ]->status == 1) {
                        ?>
                        <a href="<?php echo e(url('/unfollow/'.$user->id)); ?>" class="btn btn-primary">Unfollow</a>
                        <?php
                        }else {
                        ?>
                        <a href="<?php echo e(url('/follow/'.$user->id)); ?>" class="btn btn-primary">Follow</a>
                        <?php
                        }
                        } else {
                        ?>
                        <a href="<?php echo e(url('/follow/'.$user->id)); ?>" class="btn btn-primary">Follow</a>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="panel panel-default">
                    <?php echo Form::model($user, ['method' => 'PUT', 'route' => ['user.update', $user->id],'enctype'=>'multipart/form-data', 'id' => 'user_form']); ?>

                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-6 form-group">
                                <label>Company Name<span>*</span></label>
                                <select id="company_id" name="company_id" class="form-control" readonly>
                                    <option value="">------ Select ------</option>
                                    <?php
                                    if (!empty($companies)) {
                                    foreach ($companies as $company) {
                                    ?>
                                    <option value="<?php echo e($company->id); ?>" <?php if ( $company->id == $user->company_id )
                                    {
                                        echo "selected";
                                    } ?>><?php echo e($company->company_name); ?></option>
                                    <?php
                                    }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-6 form-group">
                                <label>Full Name<span>*</span></label>
                                <input type="text" name="user_name" id="user_name" placeholder="Full Name"
                                       value="<?php echo e($user->name); ?>" class="form-control required">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-6 form-group">
                                <label>User Email<span>*</span></label>
                                <input type="text" name="user_email" id="user_email" placeholder="User Email"
                                       value="<?php echo e($user->email); ?>" class="form-control">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-6 form-group">
                                <label>Role<span>*</span></label>
                                <select id="role_id" name="role_id" class="form-control">
                                    <option value="">------ Select ------</option>
                                    <?php
                                    if (!empty($roles)) {
                                    foreach ($roles as $role) {
                                    ?>
                                    <option value="<?php echo e($role->id); ?>" <?php if ( $user->role_id == $role->id )
                                    {
                                        echo "selected";
                                    } ?>><?php echo e($role->role_name); ?></option>
                                    <?php
                                    }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-6 form-group">
                                <label for="is_active"><input type="checkbox" name="is_active"
                                                              id="is_active" <?php if ( $user->is_active == 1 )
                                    {
                                        echo "checked";
                                    } ?>>Is Active</label><br/>
                                <p class="help-block">If user is inactive, than user will not be able to login into the
                                    system.</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <label for="is_suspended"><input type="checkbox" name="is_suspended"
                                                                          id="is_suspended" <?php if ( $user->is_suspended == 1 )
                                    {
                                        echo "checked";
                                    } ?>>Suspended</label><br/>
                                <p class="help-block">If user is suspended, than user can login but will not be able to
                                    create a new post.</p>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                            <div class="row col-xs-12">
                                <div class="btn-toolbar">
                                    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-default">Back</a>
                                    <input type="submit" name="save" id="save" class="btn btn-primary">
                                </div>
                            </div>
                            <div style="clear: both;"></div>
                        </div>
                    </div>
                    <!-- </form>     -->
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>