<title>DICO - Post</title>
<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('err_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('err_msg')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('post.index')); ?>">Post</a></li>
                    <li class="active">View Post</li>
                </ol>
                <h1>Post</h1>
            </div>
            <div class="container">
                <div class="panel panel-default">
                    <form name="post_comment_form" id="post_comment_form" method="post"
                          action="<?php echo e(url('savecomment',$post->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-12 form-group">
                                    <label><b><?php echo e($post->post_title); ?></b></label><br>
                                    <small><?php echo e($post->postUser->name); ?>

                                        on <?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></small>
                                </div>
                                <div class="col-xs-12 form-group">
                                    <label><?php echo e($post->post_description); ?></label>
                                </div>
                                <div class="row col-xs-12 form-group">
                                    <input type="hidden" name="post_id" id="post_id" value="<?php echo e($post->id); ?>">
                                    <div class="col-md-2">
                                        <a href="javascript:void(0)" id="like_post" onclick="likePost(<?php echo e($post['id']); ?>)">

                                            <?php
                                            if(!empty($post[ 'postUserLike' ])) {
                                            ?>
                                            <i class="fa fa-thumbs-up"></i>
                                            <?php } else { ?>
                                            <i class="fa fa-thumbs-o-up"></i>
                                            <?php } ?>
                                        </a>
                                        <span id="post_like_count"><?php echo count($post[ 'postLike' ]);?></span>
                                    </div>
                                    <div class="col-md-2">
                                        <a href="javascript:void(0)" id="dislike_post" onclick="dislikePost(<?php echo e($post['id']); ?>)">
                                            <?php
                                            if(!empty($post[ 'postUserUnLike' ])) {
                                            ?>
                                            <i class="fa fa-thumbs-down" aria-hidden="true"></i>
                                            <?php } else { ?>
                                            <i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
                                            <?php } ?>
                                        </a>
                                        <span id="post_dislike_count"><?php echo count($post[ 'postUnLike' ]);?></span>
                                    </div>
                                    <?php if($post->idea_status == null && $currUser->role_id < 3): ?>
                                        <div class="col-md-2"><a class="btn btn-success ideaStatus"
                                                                 href="javascript:void(0)" data-post-status="approve">Approve</a>
                                        </div>
                                        <div class="col-md-2"><a class="btn btn-danger ideaStatus"
                                                                 href="javascript:void(0)"
                                                                 data-post-status="deny">Deny</a></div>
                                        <div class="col-md-2"><a class="btn btn-warning ideaStatus"
                                                                 href="javascript:void(0)" data-post-status="amend">Amend</a>
                                        </div>
                                    <?php else: ?>
                                        <?php if($post->idea_status == null): ?>
                                            <div class="col-md-6"><strong>Action is yet to be taken on this post.</strong></div>
                                        <?php else: ?>
                                            <?php
                                                $ideaStatus = '';
                                                if($post->idea_status === 'approve')
                                                    $ideaStatus = 'Approved';
                                                else if($post->idea_status === 'deny')
                                                    $ideaStatus = 'Denied';
                                                else if($post->idea_status === 'amend')
                                                    $ideaStatus = 'Amended';
                                            ?>
                                            <div class="col-md-6"><?php echo e($ideaStatus); ?> by: <strong><?php echo e($post->ideaUser->name); ?></strong></div>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-xs-12 btn-toolbar">
                                        <a href="<?php echo e(route('post.index')); ?>" class="btn btn-default">Back</a>
                                        <?php if($currUser->id == $post->user_id): ?>
                                            <a href="<?php echo e(route('idea.edit',$post->id)); ?>" class="btn btn-primary">Edit</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>