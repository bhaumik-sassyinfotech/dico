<title>DICO - Profile</title>
<?php $__env->startSection('content'); ?>

    <div id="page-content" class="profile-page">
        <div id='wrap'>
            <div class="container">
                <div class="row">
                    <div class="follow_box col-sm-12 col-md-2">
                        <div id="follow-box">
                            <div class="preview-box">
                                <?php
$profile_image = '';
if (!empty($user->profile_image)) {
	$profile_image = asset(PROFILE_PATH . $user->profile_image);
} else {
	$profile_image = asset('public/assets/demo/avatar/jackson.png');
}
?>
                                <img src="<?php echo e($profile_image); ?>" id="user-profile">
                            </div>
                            <?php //dd($user->followers); ?>
                            <?php
                                if(!empty($follow->followers) && count($follow->followers) > 0) {
                            ?>
                            <a href="<?php echo e(url('/unfollow/'.$user->id)); ?>">Unfollow</a>
                            <?php
                                } else {
                            ?>
                            <a href="<?php echo e(url('/follow/'.$user->id)); ?>"> Follow</a>
                            <?php } ?>
                            <?php /*if(Auth::user()->id != $user->id) {
                                 ?>@if(!empty($user->followers) && count($user->followers) > 0 && in_array(Auth::user()->id, array_pluck($user->followers,'sender_user_id')))
                                    @if($user->followers[0]->status == 1)
                                        <a href="{{ url('/unfollow/'.$user->id) }}">Unfollow</a>
                                    @else
                                        <a href="{{ url('/follow/'.$user->id) }}"> Follow</a>
                                    @endif
                                @else
                                    <a href="{{ url('/follow/'.$user->id) }}" >Follow</a>
                                @endif <?php
                            }*/
                            ?>
                            <div style="display: none;" class="modal fade" id="followers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close-button-small" data-dismiss="modal" aria-hidden="true"></button>
                                            <h3>Followers(<?php echo e((isset($user->followers)) ? count($user->followers) : 0); ?>)</h3>
                                            <div class="followers-list">
                                                <?php if(!empty($user->followers) && count($user->followers) > 0): ?>
                                                    <?php $__currentLoopData = $user->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="followers-details">
                                                            <div class="follow-img">
                                                                <?php
$profile_image = '';
if (!empty($follower->followUser->profile_image)) {
	$profile_image = asset(PROFILE_PATH . $follower->followUser->profile_image);
} else {
	$profile_image = asset('public/assets/demo/avatar/jackson.png');
}
?>
                                                                <img src="<?php echo e($profile_image); ?>" alt="followers" >
                                                            </div>
                                                            <div class="follow-name">
                                                                <p><?php echo e($follower->followUser->name); ?></p>
                                                                <a href="mailto:<?php echo e($follower->followUser->email); ?>"><?php echo e($follower->followUser->email); ?></a>
                                                            </div>
                                                            <?php
                                                                $str='';
                                                                if($follower->followUser->role_id == '1') {
                                                                    $str = 'Super Admin';
                                                                    $cls = "su";
                                                                }
                                                                else if($follower->followUser->role_id == '2') {
                                                                    $str = 'Admin';
                                                                    $cls = "adm";
                                                                }
                                                                else {
                                                                    $str='Employee';
                                                                    $cls = "emp";
                                                                }
                                                            ?>
                                                            <p class="jobs-title <?php echo e($cls); ?>"><?php echo e($str); ?></p>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <div class="followers-details">
                                                        <p class="jobs-title emp">No followers yet</p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                        </div>

                                    </div><!-- /.modal-content -->
                                </div><!-- /.modal-dialog -->
                            </div>
                            <div style="display: none;" class="modal fade" id="following" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close-button-small" data-dismiss="modal" aria-hidden="true"></button>
                                            <h3>Following(<?php echo e((isset($user->following)) ? count($user->following) : 0); ?>)</h3>
                                            <div class="followers-list">
                                                <?php if(!empty($user->following) && count($user->following) > 0): ?>
                                                    <?php $__currentLoopData = $user->following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="followers-details">
                                                            <div class="follow-img">
                                                                <?php
                                                                $profile_image = '';
                                                                if (!empty($following->followingUser->profile_image)) {
                                                                        $profile_image = asset(PROFILE_PATH . $following->followingUser->profile_image);
                                                                } else {
                                                                        $profile_image = asset('public/assets/demo/avatar/jackson.png');
                                                                }
                                                                ?>
                                                                <img src="<?php echo e($profile_image); ?>" alt="followers" >
                                                            </div>
                                                            <div class="follow-name">
                                                                <p><?php echo e($following->followingUser->name); ?></p>
                                                                <a href="mailto:<?php echo e($following->followingUser->email); ?>"><?php echo e($following->followingUser->email); ?></a>
                                                            </div>
                                                            <?php
                                                                $str='';
                                                                if($following->followingUser->role_id == '1') {
                                                                    $str = 'Super Admin';
                                                                    $cls = "su";
                                                                }
                                                                else if($following->followingUser->role_id == '2') {
                                                                    $str = 'Admin';
                                                                    $cls = "adm";
                                                                }
                                                                else {
                                                                    $str='Employee';
                                                                    $cls = "emp";
                                                                }
                                                            ?>
                                                            <p class="jobs-title <?php echo e($cls); ?>"><?php echo e($str); ?></p>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <div class="followers-details">
                                                        <p class="jobs-title emp">No followers yet</p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                        </div>

                                    </div><!-- /.modal-content -->
                                </div><!-- /.modal-dialog -->
                            </div>
                        </div>
                    </div>
                    <div class="follow-block col-sm-12 col-md-10">
                        <div class="group-box">
                            <div class="group-item one">
                                <p>Name : <span><?php echo e($user->name); ?></span></p>
                                <p>Email Id : <span><?php echo e($user->email); ?></span></p>
                                <p>Role : <span><a href="#"><?php if($user->role_id == '2'): ?> <?php echo e("Company Admin"); ?> <?php elseif($user->role_id == '3'): ?> <?php echo e("Employee"); ?> <?php else: ?> <?php echo e("Super Admin"); ?> <?php endif; ?></a></span></p>
                                <p>Points : <span><?php echo e($points); ?></span></p>
                            </div>
                            <div class="group-item two">
                                <h2><?php echo e(isset($user->followers) ? count($user->followers) : 0); ?></h2>
                                <p><a href="#followers" data-toggle="modal">Followers</a></p>
                            </div>
                            <div class="group-item three">
                                <h2><h2><?php echo e(isset($user->following) ? count($user->following) : 0); ?></h2></h2>
                                <p><a href="#following" data-toggle="modal">Following</a></p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="container">

                <div class="row group-listing">
                    <div class="col-sm-12 col-md-12">
                        <div class="panel panel-midnightblue group-tabs profile-user-tabs">
                            <div class="panel-heading">
                                <h4>
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a data-toggle="tab" href="#threads"><i class="fa fa-list visible-xs icon-scale hidden-xs"></i><span>User Groups</span></a></li>
                                    </ul>
                                </h4>
                                <div class="pull-right">
                                    <div class="search-form">
                                        <input type="hidden" id="user_id" value="<?php echo e($user_id); ?>" name="">
                                        <input type="text" id="search_group_text" placeholder="Search Group">
                                        <input type="button" value="#" id="search_group_btn" class="search-icon">
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div id="threads" class="tab-pane active" style="overflow-y: hidden;" tabindex="5000">
                                        <div  class="profile-slider owl-carousel" id="view_user_groups">
                                            <?php if( count($groupDetails) > 0 && !empty($groupDetails)): ?>
                                                <?php $__currentLoopData = $groupDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="item">
                                                        <div class="list-block">
                                                            <div class="panel-heading">
                                                            </div>
                                                            <div class="panel-body">
                                                                <fieldset>
                                                                    <div class="grid-image">
                                                                        <?php
                                                                            if(empty($group->group_image))
                                                                                $group_img = asset('assets/img/business-development.png');
                                                                            else
                                                                                $group_img = asset('assets/img/'.$group->group_image);
                                                                        ?>
                                                                        <img alt="super-user" src="<?php echo e(asset('assets/img/custome-service.png')); ?>">
                                                                    </div>
                                                                    <div class="grid-details">
                                                                        <h4><?php echo e($group->group_name); ?></h4>
                                                                    </div>
                                                                </fieldset>
                                                                <p class="profanity">
                                                                    <?php echo e($group->description); ?>

                                                                </p>
                                                                <div class="panel-body-wrap">
                                                                    <div class="follower-text pull-left">
                                                                        <p>Total Posts:<span><?php echo e($group->total_posts); ?></span></p>
                                                                    </div>
                                                                    <div class="follower-text pull-right">
                                                                        <p>Total Members:<span><?php echo e($group->total_members); ?></span></p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div class="row">
                                                    <div class="col-xs-12">
                                                        <p>No data found.</p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="panel panel-midnightblue group-tabs profile-post-tabs">
                            <div class="panel-heading">
                                <h4>
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a data-toggle="tab" href="#threads"><i class="fa fa-list visible-xs icon-scale hidden-xs"></i><span>User Posts</span></a></li>
                                    </ul>
                                </h4>
                                <div class="options">
                                    <div class="btn-toolbar">
                                        <div class="btn-left  hidden-xs">
                                            <div class="btn-group color-changes">
                                                <a style="display: none;" data-toggle="dropdown" class="btn btn-default dropdown-toggle" href="#"><i aria-hidden="true" class="fa fa-filter fa-6"></i><span class="hidden-xs hidden-sm hidden-md">Filter</span> </a>
                                                <ul class="dropdown-menu">
                                                    <li><a href="#">Notification off</a></li>
                                                    <li><a href="#">Edit Post</a></li>
                                                    <li><a href="#">Delete Post</a></li>
                                                </ul>
                                            </div>

                                        </div>
                                        <a class="btn-left ">
                                            <div class="search-form">
                                                <input type="text" placeholder="Search Post">
                                                <input type="button" value="#" class="search-icon">
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div id="threads" class="tab-pane active" style="overflow-y: hidden;" tabindex="5000">
                                        <div  class="post-slider owl-carousel">
                                            <?php if(count($userPosts)): ?>
                                                <?php $__currentLoopData = $userPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="item">
                                                        <?php
                                                            $panelClass = '';
                                                            $question_type = $post->post_type;
                                                            if($question_type == 'idea')
                                                                $panelClass = 'panel-1';
                                                            else if($question_type == 'question')
                                                                $panelClass = 'panel-2';
                                                            else
                                                                $panelClass = 'panel-3';
                                                        ?>

                                                        <div class="<?php echo e($panelClass); ?> panel-primary">
                                                            <div class="panel-heading">
                                                                <h4 class="icon"><?php echo e(ucfirst($question_type)); ?></h4>
                                                                <div class="pull-right">
                                                                    <form action="<?php echo e(route('deletePost')); ?>" method="post" id="delete_post_form">
                                                                        <input type="hidden" value="<?php echo e($post->id); ?>">
                                                                        <a href="#"> <i aria-hidden="true" class="fa fa-bell-o"></i></a>
                                                                        <?php if($post->user_id == Auth::user()->id): ?>
                                                                            <a href="<?php echo e(route('post.edit',[$post->id])); ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                                                            <a href="javascript:;" class="delete_post_btn">
                                                                                <i class="fa fa-trash-o" aria-hidden="true"></i>
                                                                            </a>
                                                                        <?php endif; ?>
                                                                    </form>
                                                                </div>

                                                            </div>
                                                            <div class="panel-body">
                                                                <h4><a class="profanity" href="<?php echo e(url('viewpost/'.Helpers::encode_url($post->id))); ?>"><?php echo e($post->post_title); ?></a></h4>
                                                                <p class="user-icon">-<?php echo e($post->postUser->name); ?><span>on <?php echo e(date('Y-m-d H:i' , strtotime($post->created_at))); ?></span></p>
                                                                <fieldset>
                                                                    <p class="profanity"><?php echo e($post->post_description); ?></p>
                                                                </fieldset>
                                                                <div class="btn-wrap">
                                                                    <a href="#">Read More</a>
                                                                </div>
                                                                <div class="panel-body-wrap">
                                                                    <div class="wrap-social pull-left">
                                                                        <div class="wrap-inner-icon"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i><span><?php echo e((isset($post->postLike) && count($post->postLike) != 0) ? count($post->postLike) : 0); ?></span></div>
                                                                        <div class="wrap-inner-icon"><i class="fa fa-eye" aria-hidden="true"></i> <span><?php echo e(isset(Helpers::postViews($post->id)['views']) ? Helpers::postViews($post->id)['views'] : 0); ?></span></div>
                                                                        <div class="wrap-inner-icon"><i class="fa fa-comment-o" aria-hidden="true"></i><span><?php echo e((isset($post->postComment) && count($post->postComment) != 0) ? count($post->postComment) : 0); ?></span></div>
                                                                    </div>
                                                                    <div class="status pull-right">
                                                                        <p>Status:<span><?php echo e($post->status == '1' ? 'Active' : 'Inactive'); ?></span></p>
                                                                    </div>
                                                                </div>
                                                                <hr>
                                                                <div class="post-circle">
                                                                    <?php if(isset($post->postTag)): ?>
                                                                        <?php $__currentLoopData = $post->postTag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <a href="<?php echo e(url('tag/'.Helpers::encode_url($tag->tag->id))); ?>"> <?php echo e($tag->tag->tag_name); ?></a>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div class="row">
                                                    <div class="col-xs-12">
                                                        <p>No data found.</p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
//        alert($('.sec_question').length);
            //$('.sec_question').trigger('change');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>