<title>DICO - Group</title>
<?php $__env->startSection('content'); ?>
<div id="page-content" class="create-user create-user-popup">
                   <div id='wrap'>
                        <div id="page-heading">
                            <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('group.index')); ?>">Group</a></li>
                    <li class="active">Create Group</li>
                </ol>
                            <h1 class="tp-bp-0">Create Group</h1>
                            <hr class="border-out-hr">

                        </div>
                    <div class="container">
                        <div class="row">
                       <div id="create-user-from">
                                        <?php echo e(Form::open([ 'name' => 'createUserGroup', 'class' => 'common-form' ,'route' => 'group.store' , 'id' => 'createUserGroup'] )); ?>

                                             <div class="form-group">
                                                <label class="text-15" for="group_name">Group name:*</label>
                                                <input type="text" name="group_name" id="group_name" class="required" value=" <?php echo e(old('group_name')); ?>"/>
                                             </div>

                                             <div class="form-group">
                                                <label class="text-15" for="group_description"> Group Description: </label>
                                                <textarea name="group_description" id="group_description"
                                              class="form-control"><?php echo e(old('group_description')); ?></textarea>
                                             </div>

                                             <div class="form-group">
                                                <label class="text-15" for="company_listing">Company:* </label>

                                            <div class="select">
                                                                                                            <select name="company_listing" class="required" id="company_listing">
                                        <option value="">Select Company</option>
                                        <?php if(!is_null(old('company_listing'))): ?>
                                            <?php $company_id = old('company_listing');?>
                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($company_id == $company->id ? 'selected' : ''); ?> value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                            </div>
                                             </div>
                                             <div class="form-group">
                                                <label class="text-15" for="group_owner">Group owner:* </label>
                                                <div class="select">
                                                    <select name="group_owner" id="group_owner" class="required">
                                                        <option value="">Select user</option>
                                                    </select>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                <label class="text-15" for="users_listing" >Users:* </label>
                                                <div class="select">
                                                    <select name="users_listing[]" id="users_listing" class="required"
                                                        multiple="multiple" placeholder="Select company first" >
                                                </select>
                                                </div>
                                             </div>
                                             <div class="form-group">
                                                 <div class="btn-wrap-div">
                                                      <input type="submit" name="submit" class="st-btn">
                                                      <a class="st-btn" href="<?php echo e(route('group.index')); ?>">Back</a>
                                                 <!-- <input type="reset" class="st-btn" value="Cancel"> -->
                                                 </div>
                                             </div>

                                         <?php echo e(Form::close()); ?>



                                     </div>
                            </div>
                        </div>

                     </div>
        </div> <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>