
<title>DICO - Profile</title>
<?php $__env->startSection('content'); ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('err_msg')): ?>
<div class="alert alert-danger">
    <?php echo e(session()->get('err_msg')); ?>

</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <h1>Profile</h1>
        </div>    
        <div class="container">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="tab-content">
                        <div class="tab-pane active" id="domtabs">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="tab-container tab-danger">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#general_tab" data-toggle="tab">General</a></li>
                                        </ul>
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="general_tab">
                                                <form name="view_profile_form" id="view_profile_form" method="post">
                                                    <div class="pull-right extra_button">
                                                    <?php
                                                        if(!empty($user->following) && count($user->following) > 0) {
                                                            if($user->following[0]->status == 1) {
                                                    ?>
                                                        <a href="<?php echo e(url('/unfollow/'.$user->id)); ?>" class="btn btn-primary" >Unfollow</a>
                                                    <?php 
                                                            }else {
                                                            ?>
                                                            <a href="<?php echo e(url('/follow/'.$user->id)); ?>" class="btn btn-primary" >Follow</a>
                                                            <?php
                                                            }
                                                    } else {
                                                    ?>
                                                        <a href="<?php echo e(url('/follow/'.$user->id)); ?>" class="btn btn-primary" >Follow</a>
                                                    <?php } ?>
                                                    </div>
                                                    <?php
                                                    if (!empty($user->profile_image)) {
                                                        $profile_image = 'public/uploads/profile_pic/' . $user->profile_image;
                                                    } else {
                                                        $profile_image = 'public/assets/demo/avatar/jackson.png';
                                                    }
                                                    ?>
                                                    <img src="<?php echo e(asset($profile_image)); ?>" id="profile" alt="" class="pull-left" height="100px" width="100px" style="margin: 0 20px 20px 0">
                                                    <div class="row">
                                                        <div class="col-xs-12 form-group">
                                                            <label><b>Name:</b></label>
                                                            <label><?php echo e($user->name); ?></label>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xs-12 form-group">
                                                            <label><b>Email:</b></label>
                                                            <label><?php echo e($user->email); ?></label>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xs-12 form-group">
                                                            <label><b>Google Link:</b></label>
                                                            <?php if(!empty($user->google_id)) { $google_link = $user->google_id;} else { $google_link = ' - ';}?>
                                                            <label><?php echo e($google_link); ?></label>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-xs-12 form-group">
                                                            <label><b>LinkedIn Link:</b></label>
                                                            <?php if(!empty($user->linkedin_id)) { $linkedin_link = $user->linkedin_id;} else { $linkedin_link = ' - ';}?>
                                                            <label><?php echo e($linkedin_link); ?></label>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
//        alert($('.sec_question').length);
        //$('.sec_question').trigger('change');
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>