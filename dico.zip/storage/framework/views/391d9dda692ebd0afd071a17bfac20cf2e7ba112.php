<title>DICO - User</title>
<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('err_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('err_msg')); ?>

        </div>
    <?php endif; ?>
    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li class="active">User</li>
                </ol>
                <h1>User</h1>
                <div class="options">
                    <div class="btn-toolbar">
                        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary">Add New</a>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <form method="POST" id="user-search-form" class="form-inline" role="form">
                            <div class="form-group">
                                <label for="name">User Name</label>
                                <input type="text" class="form-control" name="user_name" id="user_name"
                                       placeholder="user name">
                            </div>
                            <div class="form-group">
                                <label for="email">User Email</label>
                                <input type="text" class="form-control" name="user_email" id="user_email"
                                       placeholder="user email">
                            </div>
                            <div class="form-group">
                                <label for="company">Company</label>
                                <select id="company_id" name="company_id" class="form-control">
                                    <option value="">------ Select ------</option>
                                    <?php
                                    if(!empty($companies)) {
                                    foreach($companies as $company) {
                                    ?>
                                    <option value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
                                    <?php
                                    }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="role">Role</label>
                                <select id="role_id" name="role_id" class="form-control">
                                    <option value="">------ Select ------</option>
                                    <?php
                                    if(!empty($roles)) {
                                    foreach($roles as $role) {
                                    ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_name); ?></option>
                                    <?php
                                    }
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Search</button>
                        </form>
                        <table class="table table-striped" id="users-table">
                            <thead>
                            <tr>
                                <th>ID#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Company</th>
                                <th>Role</th>
                                <th>Active</th>
                                <th>Suspended</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>