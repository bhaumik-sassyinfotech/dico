<title>DICO - Points</title>
<?php $__env->startSection('content'); ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('err_msg')): ?>
<div class="alert alert-danger">
    <?php echo e(session()->get('err_msg')); ?>

</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('points.index')); ?>">Points</a></li>
                <li class="active">Update Points</li>
            </ol>
            <h1>Points</h1>
        </div>
        <div class="container">
            <div class="panel panel-default">
                <?php echo Form::model($point, ['method' => 'PUT', 'route' => ['points.update', $point->id],'enctype'=>'multipart/form-data', 'id' => 'points_form']); ?>

                    
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <label>Activity<span>*</span></label>
                                <input type="text" name="activity" id="activity" value="<?php echo e($point->activity); ?>" placeholder="Activity" class="form-control required">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <label>Points<span>*</span></label>
                                <input type="text" name="points" id="points" value="<?php echo e($point->points); ?>" placeholder="Points" class="form-control required">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <label>Notes</label>
                                <textarea name="notes" id="notes" placeholder="Notes" class="form-control"><?php echo e($point->notes); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div class="row col-xs-12">
                            <div class="btn-toolbar">
                                <a href="<?php echo e(route('points.index')); ?>" class="btn btn-default" >Back</a>
                                <input type="submit" name="save" id="save" class="btn btn-primary">
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                    </div>
               <!-- </form>     -->
               <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>