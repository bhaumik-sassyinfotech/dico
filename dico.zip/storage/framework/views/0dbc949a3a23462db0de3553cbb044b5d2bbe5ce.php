<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-dismissable alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('err_msg')): ?>
        <div class="alert alert-dismissable alert-danger">
            <?php echo e(session()->get('err_msg')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-dismissable alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('meeting.index')); ?>">Meeting</a></li>
                    <li class="active">Create Meeting</li>
                </ol>
                <h1>Create Meeting</h1>
            </div>
            <?php echo e(Form::open([ 'name' => 'createMeeting','route' => 'meeting.store' , 'id' => 'createMeeting'] )); ?>

            <div class="container">
                <div class="panel panel-default">
                    
                    
                    
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="meeting_title" class="control-label">Meeting title:*</label>
                                    <input type="text" name="meeting_title" id="meeting_title" class="form-control required"/>
                                </div>
                                <div class="col-md-6">
                                    <label class="control-label" for="meeting_description"> Meeting description: </label>
                                    <textarea name="meeting_description" id="meeting_description"
                                              class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="company_id" value="<?php echo e($company_id); ?>">
                        <div class="form-group ">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="group_listing" class="control-label">Groups: </label>
                                    <select name="group_listing" class="form-control required" id="group_listing">
                                        <option value="">Select groups</option>
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($group->id); ?>"><?php echo e($group->group_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="employees_listing">Employees: </label>
                                    <select name="employees[]" id="employees_listing" class="form-control" multiple="multiple">
                                        <option value="">Select employees</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="" style="width:100%;">&nbsp;&nbsp;&nbsp;&nbsp;</label>
                                    <label class="checkbox-inline"><input class="privacy_type" type="checkbox" name="privacy[]" id="public" value="public">Public</label>
                                </div>
                                <div class="col-md-2">
                                    <label for="" style="width:100%;">&nbsp;&nbsp;&nbsp;&nbsp;</label>
                                    <label class="checkbox-inline"><input class="privacy_type" type="checkbox" name="privacy[]" id="private" value="private">Private</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="btn-toolbar">
                                    <a class="btn btn-default" href="<?php echo e(route('group.index')); ?>">Back</a>
                                    <?php echo e(Form::submit('Submit',['class' => 'btn btn-primary'])); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>