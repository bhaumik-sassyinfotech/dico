<title>DICO - Meeting</title>
<?php $__env->startSection('content'); ?>
<div id="page-content" class="new-meeting-details">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('meeting.index')); ?>">Meeting</a></li>
                <li class="active">Edit Meeting</li>
            </ol>
            <h1 class="tp-bp-0">Edit Meeting</h1>
            <hr class="border-out-hr">
        </div>
        <div class="container">
            <div class="row">
               <!-- <div id="company-from">-->
                <?php echo Form::open(['method' => 'PUT', 'route' => ['meeting.update', Helpers::encode_url($meeting->id)],'enctype'=>'multipart/form-data', 'id' => 'meeting_edit_form' , 'class' => 'common-form']); ?>

                <div class="col-sm-8" id="post-detail-left">    
                    <div class="form-group">
                        <label>Type*</label>
                        <div class="check-wrap">
                            <label class="check">Private
                                <input class="privacy_type post_type" type="checkbox" <?php echo e(($meeting->privacy == '1') ? 'checked':''); ?> name="privacy" id="private" value="private">
                                <span class="checkmark"></span>
                            </label>
                            <label class="check">Public
                                <input class="privacy_type post_type" type="checkbox" <?php echo e(($meeting->privacy == '0') ? 'checked':''); ?> name="privacy" id="public" value="public">
                                <span class="checkmark"></span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="text-15">Meeting Title<span>*</span></label>
                        <input type="text" name="meeting_title" id="meeting_title" value="<?php echo e($meeting->meeting_title); ?>" placeholder="Meeting title" class="form-control required">
                    </div>

                    <div class="form-group">
                        <label class="text-15">Meeting Description</label>
                        <textarea name="meeting_description" id="meeting_description" placeholder="Meeting Description" class="form-control"><?php echo e(nl2br($meeting->meeting_description)); ?></textarea>
                    </div>
                
                    <div class="form-group calendar">
                        <label>Date Of Meet:</label>   
                        <div class='input-group date' id='datetimepicker1'>
                            <?php
                                $date_of_meet = !empty($meeting->date_of_meeting) ? date(DATETIME_FORMAT,strtotime($meeting->date_of_meeting)) : '';
                            ?>
                            <input type="text" name="date_of_meet" id="date_of_meet" value="<?=$date_of_meet?>" placeholder="<?=$date_of_meet?>" style="pointer-events: none;" class="form-control">
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>

                    <div class="btn-wrap-div">
                    <input type="submit" class="st-btn" value="Submit">
                    <?php /*<div class="upload-btn-wrapper">
                        <button class="upload-btn">Upload Files</button>
                        <input type="file" name="file_upload" id="file_upload" class="file-upload__input">
                    </div>*/?>
                </div>
               </div>
               <div class="col-sm-4" id="post-detail-right">
                    <h3 class="heading-title">INVITE BY:</h3>
                        <div class="category-meeting">
                            <div class="tab-container tab-success new-meeting-tab">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#home1">Groups </a></li>
                                    <li class=""><a data-toggle="tab" href="#profile1">Members</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane clearfix active" id="home1">
                                        <div class="main-group-wrap">
                                          <div class="category-tab"> 
                                            <label class="check">Groups<input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                          </div>
                                            <div class="category-detials">
                                                <?php
                                                    if(!empty($meeting->group_id)) {
                                                    $meeting_group = explode(",",$meeting->group_id);
                                                    } else {
                                                        $meeting_group = array();
                                                    }
                                                ?>
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="check" style="display: block !important;"><?php echo e($group->group_name); ?>

                                                    <input name="group[]" type="checkbox" <?php if(in_array($group->id,$meeting_group)) { echo "checked";}?> id="group_<?php echo e($group->id); ?>" value="<?php echo e($group->id); ?>">
                                                    <span class="checkmark"></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            </div>   
                                    </div>   
                                    </div>        
                                    <div id="profile1" class="tab-pane">

                                        <div class="category-tab">   
                                            <?php
                                                if(!empty($meeting->meetingUsers)) {
                                                    $meetingUsers = array_pluck($meeting->meetingUsers,'user_id');
                                                } else {
                                                    $meetingUsers = array();
                                                }
                                            ?>
                                                <select name="employees[]" id="employees_listing" class="form-control" style="width: 84%">
                                                <option value="-1">---Select---</option>
                                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($employee->id); ?>" <?php if(in_array($employee->id,$meetingUsers)) { echo "disabled";} ?>><?php echo e($employee->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <input type="submit" name="add_employee" id="add_employee" value="ADD" class="st-btn">
                                                <input type="hidden" id="selected_members" name="selected_members">
                                          </div> 
                                        <div class="post-category" id="meeting_users_list">
                                            <?php
                                                //dd($meeting->meetingUsers);
                                                if(!empty($meeting->meetingUsers) && count($meeting->meetingUsers) > 0) {
                                                    foreach ($meeting->meetingUsers as $meetingUsers) {
                                                        $userDetail = $meetingUsers->UserDetail;
                                                        if($meetingUsers->group_id != 0) {
                                            ?>
                                            <div class="member-wrap" id="user_<?php echo $userDetail->id;?>">
                                                <div class="member-img">
                                                    <?php
                                                        if (!empty($userDetail->profile_image)) {
                                                            $profile_image = PROFILE_PATH . $userDetail->profile_image;
                                                        } else {
                                                            //$profile_image = 'public/assets/demo/avatar/jackson.png';
                                                            $profile_image = DEFAULT_PROFILE_IMAGE;
                                                        }
                                                    ?>
                                                    <img alt="no" src="<?php echo e(asset($profile_image)); ?>">
                                                </div>
                                                <div class="member-details">
                                                    <h3 class="text-12"><?php echo e($userDetail->name); ?></h3>
                                                    <a href="mailto:<?php echo e($userDetail->email); ?>"><?php echo e($userDetail->email); ?></a>
                                                </div>
                                                <a href="javascript:void(0)" onclick="removeMember(<?php echo e($userDetail->id); ?>)" class="close-button-small"></a>
                                            </div>
                                            <?php } } } ?> 
                                        </div> 

                                    </div>
                                </div>
                                </div>
                                </div>  
                                <div class="category files">
                  <h2>Uploaded Files</h2>
                  <div class="wrap-name-upload">
                        <div class="select">
                            <select id="slct" name="slct">
                                    <option>Name</option>
                                    <option>Admin</option>
                                    <option value="Super User">Super User</option>
                                    <option value="Employee">Employee</option>
                            </select>
                        </div>
                        <input type="hidden" name="company_id" value="<?php echo e($company_id); ?>">
                        <div class="upload-btn-wrapper">
                                    <form name="uploadfile" id="uploadfile" method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="meetingId" id="meetingId" value="<?php echo e($meeting['id']); ?>">
                                        <button class="btn" id="uploadBtn">Upload File</button>
                                        <input name="file_upload" id="file_upload" type="file" onchange="uploadFileMeeting();">
                                    </form>
                                </div>
                            </div>
                            <div class="idea-grp post-category" id="meetingAttachment">
                        <?php
                            if(!empty($meeting->meetingAttachment) && count($meeting->meetingAttachment) > 0) {
                            foreach($meeting->meetingAttachment as $attachment) {
                        ?>
                        <div class="member-wrap files-upload">

                            <div class="member-img">
                                <img src="<?php echo e(asset(DEFAULT_ATTACHMENT_IMAGE)); ?>" alt="no">
                            </div>
                            <div class="member-details">
                                <h3 class="text-10"><?php echo e($attachment->file_name); ?></h3>
                                <p>Uploaded By:<a href="#"><?php echo e($attachment->attachmentUser->name); ?></a></p>
                            </div>
                        </div>    
                            <?php } }
                                else {
                                    echo "<p class='text-12'>No files uploaded.</p>";
                                }
                            ?>
                    </div>  
                </div> 
                </div>
                <?php echo Form::close(); ?>

                
               <!-- </div>-->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            var selected_members = [];
            $('#meeting_users_list div.member-wrap').each(function() {
                var userid = $(this).attr('id');
                var user = userid.split("_").slice(-1);
                selected_members.push(user[0]);
            });
            $('#selected_members').val(selected_members);
        });
        $('#datetimepicker1').datetimepicker({
           // minDate : new Date(),
        });
        $("#meeting_edit_form").validate({
            rules:{
                'meeting_title':{
                    required: true,
                }
            },
            submitHandler: function (form) {
                $('.save').prop('disabled',true);
                form.submit();
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>