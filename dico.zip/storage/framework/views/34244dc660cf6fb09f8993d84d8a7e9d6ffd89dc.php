
<?php $__env->startSection('content'); ?>


    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li class="active">Group</li>
                </ol>
                <h1>Group</h1>
                
            </div>

            <div class="container">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                        <?php endif; ?>
                        <?php if(session()->has('err_msg')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('err_msg')); ?>

                        </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <table class="table table-bordered table-striped" id="group_table">
                            <thead>
                                <tr>
                                    <th>#ID</th>
                                    <th>Group Name</th>
                                    <th>Group Description</th>
                                    <th>Total members</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>