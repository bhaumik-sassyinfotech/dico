
<title>DICO - Post</title>
<?php $__env->startSection('content'); ?>

<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li class="active">Post</li>
            </ol>
            <h1>Post</h1>
            <div class="options">
                <div class="btn-toolbar">
                    <div class="btn-group hidden-xs">
                        <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary">Add New</a>
                    </div>
                </div>
            </div>
        </div>    
        <div class="container">
            <div class="panel panel-default">
                <div class="panel-body">
    
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('success')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('err_msg')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('err_msg')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="POST" id="post-search-form" class="form-inline" role="form">
                    </form>
                    <?php
                    //dd($posts);
                    if (!empty($posts)) {
                        foreach (array_chunk($posts, 3) as $p) {
                            //dd($post['post_title']);
                            ?>
                            <div class="row">
                                <?php
                                foreach ($p as $post) {
                                    // dd($post);
                                    ?>
                                    <div class="col-md-4">
                                        <div class="info-tiles tiles-info">
                                            <div class="tiles-heading">
                                                <div class="pull-left"><a href="<?php echo e(url('viewpost', Helpers::encode_url($post['id']))); ?>"><?php echo e(str_limit($post['post_title'], $limit = 50, $end = '...')); ?></a></div>
                                            </div>
                                            <div class="tiles-body">
                                                <div class="row-md-4" style="font-size: 20px !important;">
                                                    <?php echo e(str_limit($post['post_description'], $limit = 130, $end = '...')); ?>

                                                </div>
                                                <div class="row-md-4">
                                                    <div class="col-md-2">
                                                        <a href="javascript:void(0)" id="like_post" onclick="likePost(<?php echo e($post['id']); ?>)">
                                                            <?php
                                                            if (!empty($post['post_user_like'])) {
                                                                ?>
                                                                <i class="fa fa-thumbs-up"></i>
                                                            <?php } else { ?>
                                                                <i class="fa fa-thumbs-o-up"></i>
                                                            <?php } ?>
                                                        </a>
                                                        <span id="post_like_count"><?php echo count($post['post_like']); ?></span>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <a href="javascript:void(0)" id="dislike_post" onclick="dislikePost(<?php echo e($post['id']); ?>)">
                                                            <?php
                                                            if (!empty($post['post_user_dis_like'])) {
                                                                ?>
                                                                <i class="fa fa-thumbs-down" aria-hidden="true"></i>
                                                            <?php } else { ?>
                                                                <i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
                                                            <?php } ?>
                                                        </a>
                                                        <span id="post_dislike_count"><?php echo count($post['post_dis_like']); ?></span>
                                                    </div>
                                                    <div class="col-md-2"><a href="javascript:void(0)">
                                                            <?php
                                                            if (!empty($post['post_comment'])) {
                                                                ?>
                                                                <i class="fa fa-comments"></i>
                                                            <?php } else { ?>
                                                                <i class="fa fa-comments-o"></i>
                                                            <?php } ?>
                                                        </a>
                                                        <span><?php echo count($post['post_comment']); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tiles-footer">
                                                <?php
                                                    if($post['is_anonymous'] == 0) { ?>
                                                Author : <?php echo e($post['post_user']['name']); ?> 
                                                    <?php } else { echo "Anonymous"; }?><br/>
                                                Date : <?php echo e(date('d/m/Y',strtotime($post['created_at']))); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <?php
                                }
                                ?>
                            </div>    
                            <?php
                        }
                    }
                    ?>
                    <?php /* <table class="table table-striped" id="post_table">
                      <thead>
                      <tr>
                      <th>ID#</th>
                      <th>Title</th>
                      <th>Description</th>
                      <th>Author</th>
                      <th>Date</th>
                      <th>Status</th>
                      <th>Actions</th>
                      </tr>
                      </thead>
                      </table> */ ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    function deletepost(id) {
    swal({
    title: "Are you sure?",
            text: "you will not able to recover this post.",
            type: "info",
            showCancelButton: true,
            closeOnConfirm: false,
            showLoaderOnConfirm: true
    }, function () {
    var token = '<?php echo csrf_token() ?>';
    var formData = {post_id : id, _token : token};
    $.ajax({
    url: "<?php echo e(route('post.destroy'," + id + ")); ?>",
            type: "POST",
            data: formData,
            success: function (response) {
            var res = JSON.parse(response);
            if (res.status == 1) {
            swal("Success", res.msg, "success");
            location.reload();
            }
            else {
            swal("Error", res.msg, "error");
            }
            }
    });
    });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>