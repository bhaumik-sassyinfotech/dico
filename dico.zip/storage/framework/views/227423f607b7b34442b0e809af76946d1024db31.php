<title><?php echo app('translator')->getFromJson("label.adDICO - Blog"); ?></title>
<?php $__env->startSection('content'); ?>

<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson("label.adDashboard"); ?></a></li>
                <li class="active"><?php echo app('translator')->getFromJson("label.adBlog"); ?></li>
            </ol>
            <h1><?php echo app('translator')->getFromJson("label.adBlog"); ?></h1>
            <div class="options">
                <div class="btn-toolbar">

                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12">
                    <div class="panel-body">
                        <div class="panel panel-info " style="overflow-x:auto;">
                            <div class="panel-heading trophy">
                                <h4 class="icon"><?php echo app('translator')->getFromJson("label.adBlog"); ?></h4>
                            </div>
                            <div class="panel-body">
                                <table class="table table-bordered table-striped" id="blockList">
                                    <thead>
                                        <tr>
                                            <th>#<?php echo app('translator')->getFromJson("label.adID"); ?></th>
                                            <th><?php echo app('translator')->getFromJson("label.adTitle"); ?></th>
                                            <th><?php echo app('translator')->getFromJson("label.adDescription"); ?></th>
                                            <th><?php echo app('translator')->getFromJson("label.adAction"); ?></th>
                                        </tr>
                                    </thead>

                                </table>
                                <div class="col-lg-6"></div>
                                <div class="col-lg-6">
                                    <div class="col-lg-6">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>