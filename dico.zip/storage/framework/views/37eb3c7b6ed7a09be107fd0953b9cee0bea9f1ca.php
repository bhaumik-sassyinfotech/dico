<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('err_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('err_msg')); ?>

        </div>
    <?php endif; ?>
    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                    <li class="active">Group</li>
                </ol>
                <h1>Group</h1>
                <div class="options">
                    <div class="btn-toolbar">
                        <div class="btn-group hidden-xs">
                            <a href="<?php echo e(route('group.create')); ?>" class="btn btn-primary">Add New</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <table class="table table-bordered table-striped" id="group_table">
                            <thead>
                                <tr>
                                    <th>#ID</th>
                                    <th>Group Name</th>
                                    <th>Group Description</th>
                                    <th>Total members</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>