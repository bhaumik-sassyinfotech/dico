
<title>DICO - Post</title>
<?php $__env->startSection('content'); ?>


<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('post.index')); ?>">Post</a></li>
                <li class="active">View Post</li>
            </ol>
            <h1>Post</h1>
        </div>
        <div class="container">
            <div class="panel panel-default">
                <form name="post_comment_form" id="post_comment_form" method="post" action="<?php echo e(url('savecomment',$post->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="post_id" id="post_id" value="<?php echo e($post['id']); ?>">
                    <div class="panel-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('err_msg')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('err_msg')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <label><b><?php echo e($post->post_title); ?></b></label><br>
                                <small>
                                    <?php
                                    if ($post['is_anonymous'] == 0) {

                                        echo $post->postUser->name;
                                    } else {
                                        echo "Anonymous";
                                    }
                                    ?> 
                                    on <?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></small>
                            </div>
                            <div class="col-xs-12 form-group">
                                <label><?php echo e($post->post_description); ?></label>
                            </div>
                            <div class="col-xs-12 form-group">
                                <div class="col-md-2">
                                    <a href="javascript:void(0)" id="like_post" onclick="likePost(<?php echo e($post['id']); ?>)">
                                        <?php
                                        if (!empty($post['postUserLike'])) {
                                            ?>
                                            <i class="fa fa-thumbs-up"></i>
                                        <?php } else { ?>
                                            <i class="fa fa-thumbs-o-up"></i>
                                        <?php } ?>
                                    </a>
                                    <span id="post_like_count"><?php echo count($post['postLike']); ?></span>
                                </div>
                                <div class="col-md-2">
                                    <a href="javascript:void(0)" id="dislike_post" onclick="dislikePost(<?php echo e($post['id']); ?>)">
                                        <?php
                                        if (!empty($post['postUserDisLike'])) {
                                            ?>
                                            <i class="fa fa-thumbs-down" aria-hidden="true"></i>
                                        <?php } else { ?>
                                            <i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
                                        <?php } ?>
                                    </a>
                                    <span id="post_dislike_count"><?php echo count($post['postDisLike']); ?></span>
                                </div>
                                <div class="col-md-2">
                                    <a href="javascript:void(0)">
                                        <?php
                                        if (!empty($post['postComment'])) {
                                            ?>
                                            <i class="fa fa-comments"></i>
                                        <?php } else { ?>
                                            <i class="fa fa-comments-o"></i>
                                        <?php } ?>
                                    </a>
                                    <span><?php echo count($post['postComment']); ?></span>
                                </div>
                            </div>
                        </div>  
                        <hr>
                        <div class="form-group">
                            <textarea name="comment_text" id="comment_text" class="form-control autosize" placeholder="Leave a comment here" style="overflow: hidden; word-wrap: break-word; resize: horizontal; height: 71.9792px;"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <span class="btn btn-primary fileinput-button">
                                    <i class="fa fa-upload"></i>
                                    <span>upload</span>
                                    <input type="file" name="file_upload" id="file_upload" class="file-upload__input">
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 form-group">
                                <label class="checkbox-inline"><input type="checkbox" name="is_anonymous" id="is_anonymous">Anonymous</label><br/>

                            </div>
                        </div>

                        <div class="row">
                            <?php
                            if ($post['user_id'] == Auth::user()->id) {
                            ?>
                            <a href="<?php echo e(route('post.edit',Helpers::encode_url($post->id))); ?>" class="btn btn-primary">Edit</a>

                            <?php
                            }
                            ?>
                            <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-primary">
                        </div>    
                    </div>
                </form>
                <!-- Comment Box start -->
                <form class="form-horizontal row-border">
                    <div class="panel-body">
                        <div class="row">
                            <?php

                            //dd($post['postComment']);
                            if (!empty($post['postComment'])) {
                                foreach ($post['postComment'] as $postComment) {
                                    ?>
                                    <div class="form-group" id="commentreply_<?php echo e($postComment['id']); ?>">
                                        <div class="row" style="margin:0 !important;">
                                            <div class="col-md-2">
                                                <div class="row">
                                                    <?php if (!empty($postComment['commentUser'])) { ?> 
                                                        <div class="col-md-2">
                                                            <?php
                                                            $commentUser = $postComment['commentUser'];
                                                            if (!empty($commentUser->profile_image)) {
                                                                $profile_image = 'public/uploads/profile_pic/' . $commentUser->profile_image;
                                                            } else {
                                                                $profile_image = 'public/assets/demo/avatar/jackson.png';
                                                            }
                                                            ?>
                                                            <img src="<?php echo e(asset($profile_image)); ?>" id="profile" alt="" class="pull-left" height="100px" width="100px" style="margin: 0 20px 20px 0"/>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <?php
                                                        //dd($commentUser);
                                                        $comment_id = Helpers::encode_url($commentUser->id);
                                                        if (!empty($commentUser['following']) && count($commentUser['following']) > 0 && $commentUser->id != Auth::user()->id) {
                                                            if ($commentUser['following'][0]->status == 1) {
                                                                ?>
                                                                <a href="<?php echo e(url('/view_profile/'.$comment_id)); ?>" class="btn btn-primary" >Unfollow</a>
                                                                <?php
                                                            } else {
                                                                ?>
                                                                <a href="<?php echo e(url('/view_profile/'.$comment_id)); ?>" class="btn btn-primary" >Follow</a>
                                                                <?php
                                                            }
                                                        } else if ($commentUser->id != Auth::user()->id) {
                                                            ?>
                                                            <a href="<?php echo e(url('/view_profile/'.$comment_id)); ?>" class="btn btn-primary" >Follow</a>
                                                            <?php
                                                        }
                                                    }
                                                    ?>

                                                </div>
                                            </div>
                                            <div class="col-md-10">
                                                <div class="row">
                                                    <span style="float:left;">
                                                        <?php if ($postComment['is_anonymous'] == 0) { ?>
                                                            <b><?php echo $commentUser['name']; ?></b>
                                                        <?php
                                                        } else {
                                                            echo "<b>Anonymous</b>";
                                                        }
                                                        ?><br>
                                                        <small><?php echo " - on " . date('m/d/Y', strtotime($commentUser['created_at'])); ?></small></span>
                                                            <?php if ($post['user_id'] == Auth::user()->id) { ?>
                                                        <span style="float: right;">
                                                            <a id="solution_<?php echo e($postComment['id']); ?>" href="javascript:void(0)" onclick="markSolution(<?php echo e($postComment['id']); ?>, <?php echo e($commentUser['id']); ?>, <?php echo e($post['id']); ?>)">
                                                                <?php if ($postComment['is_correct'] == 1) { ?>
                                                                    <i class="fa fa-star" aria-hidden="true"></i>
                                                                <?php } else { ?>
                                                                    <i class="fa fa-star-o" aria-hidden="true"></i>
                                                        <?php } ?>  </a>Solution
                                                        </span>
                                                    <?php
                                                    } else {
                                                        if ($postComment['is_correct'] == 1) {
                                                            ?><span style="float: right;"><a href="javascript:void(0)"><i class="fa fa-star" aria-hidden="true"></i></a> Solution</span><?php
                                                                }
                                                            }
                                                            ?><br>
        <?php if ($commentUser['id'] == Auth::user()->id) { ?>
                                                        <span style="float:right;">
                                                            <a href="<?php echo e(url('/deletecomment',$postComment['id'])); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                        </span><?php } ?>
                                                </div>
                                                <div class="row">
                                                <?php echo $postComment['comment_text']; ?>
                                                </div> 
        <?php
        if (!empty($postComment['commentAttachment'])) {
            ?>
                                                    <div class="row"><b>Attachment : </b>
                                                        <a href="#"><?php echo e($postComment['commentAttachment']['file_name']); ?></a>
                                                    </div><?php } ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-9"></div>
                                            <div class="col-md-3">
                                                <div class="col-md-1">
                                                    <a href="javascript:void(0)" id="like_comment_<?php echo e($postComment['id']); ?>" onclick="likeComment(<?php echo e($postComment['id']); ?>);" >
                                                        <?php
                                                        if (!empty($postComment['commentUserLike'])) {
                                                            ?>
                                                            <i class="fa fa-thumbs-up"></i>
        <?php } else { ?>
                                                            <i class="fa fa-thumbs-o-up"></i>
        <?php } ?>
                                                    </a>
                                                    <span id="comment_like_count_<?php echo e($postComment['id']); ?>"><?php echo count($postComment['commentLike']) ?></span>
                                                </div>
                                                <div class="col-md-1"><a href="javascript:void(0)" id="dislike_comment_<?php echo e($postComment['id']); ?>" onclick="dislikeComment(<?php echo e($postComment['id']); ?>);" >
                                                        <?php
                                                        if (!empty($postComment['commentUserDisLike'])) {
                                                            ?>
                                                            <i class="fa fa-thumbs-down"></i>
        <?php } else { ?>
                                                            <i class="fa fa-thumbs-o-down"></i>
        <?php } ?>
                                                    </a>
                                                    <span id="comment_dislike_count_<?php echo e($postComment['id']); ?>"><?php echo count($postComment['commentDisLike']); ?></span>
                                                </div>
                                                <div class="col-md-1"><a href="javascript:void(0);" data-toggle="modal" data-target="#myModal<?php echo e($postComment['id']); ?>"><i class="fa fa-reply" aria-hidden="true"></i></a></div>
                                                <div id="myModal<?php echo e($postComment['id']); ?>" class="modal fade" role="dialog">
                                                    <div class="modal-dialog">

                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                <h4 class="modal-title">Comment Here</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                   <textarea name="comment_text" id="comment_text_<?php echo e($postComment['id']); ?>" class="form-control autosize" placeholder="Leave a comment here"></textarea>
                                                                </div>
                                                                <div class="row">
                                                                    <label class="checkbox-inline"><input type="checkbox" name="is_anonymous" id="is_anonymous_<?php echo e($postComment['id']); ?>">Anonymous</label><br>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="comment_reply(<?php echo e($postComment['id']); ?>)">Submit</button>
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- comment reply box start -->
                                        <?php
                                        //dd($postComment['commentReply']);
                                        if (!empty($postComment['commentReply'])) {
                                            $srno = 0;
                                            foreach ($postComment['commentReply'] as $commentReply) {
                                                $srno++;
                                                ?>
                                        <div class="form-group row cmry" id="<?php echo e($srno); ?>"><div class="col-md-12">
                                                        <span style="float:left;">
                                                            <?php if ($commentReply['is_anonymous'] == 0) { ?>
                                                            <b><?php echo $commentReply['commentReplyUser']['name']; ?></b>
                                                        <?php
                                                        } else {
                                                            echo "<b>Anonymous</b>";
                                                        }
                                                        ?>
                                                            
                                                            <br>
                                                            <small><?php echo " - on " . date('d/m/Y', strtotime($commentReply['created_at'])); ?></small>
                                                        </span>  <br>
                                                        <div class="col-md-12">    
                <?php echo $commentReply['comment_reply']; ?></div>
                                                    </div>  
                                                <?php if ($commentReply['user_id'] == Auth::user()->id) { ?>
                                                    <span style="float:right;">
                                                        <a href="<?php echo e(url('/deletecommentReply',$commentReply['id'])); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                    </span><?php } ?></div>
                                                <?php
                                            }
                                        }
                                        ?>
                                        <!-- comment reply box end --> 
                                    </div>    
                                    <?php
                                }
                            }
                            ?>
                        </div> 
                    </div>
                </form>  
                <!-- Comment Box end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascripts'); ?>
<script type="text/javascript">
    function markSolution(commentid, userid, postid)
    {
    swal({
    title: "Are you sure?",
            text: "This will be consider as answer and publish to post user.",
            type: "info",
            showCancelButton: true,
            closeOnConfirm: true,
            showLoaderOnConfirm: true
    }, function () {
    var _token = CSRF_TOKEN;
    var formData = {comment_id:commentid, user_id:userid, post_id:postid, _token};
    $.ajax({
            url: SITE_URL + '/comment_solution',
            type: 'POST',
            data: formData,
            success: function(response) {
                var res = JSON.parse(response);
                var html = "";
            if (res.status == 1) {
                html += '<i class="fa fa-star" aria-hidden="true">';
            } else if (res.status == 2) {
                html += '<i class="fa fa-star" aria-hidden="true">';
                swal("Error", res.msg, "error");
            } else {
                html += '<i class="fa fa-star-o" aria-hidden="true">';
                swal("Error", res.msg, "error");
            }
            $('#solution_' + commentid).html(html);
            },
            error: function(e) {
            swal("Error", e, "error");
            }
    });
    });
    }
    function comment_reply(commentid) {
    
        var _token = CSRF_TOKEN;
        var post_id = $('#post_id').val();
        var comment_reply = $('#comment_text_'+commentid).val();
        var anonymous = 0;
        var srno = $('#commentreply_'+commentid+' .cmry:first').attr('id');
        if($("#is_anonymous_"+commentid).is(':checked')) {
            anonymous = 1;
        } else {
            anonymous = 0;
        }
        var formData = {comment_id:commentid, comment_reply:comment_reply,post_id:post_id,is_anonymous:anonymous,srno:srno, _token};
        $.ajax({
        url: SITE_URL + '/comment_reply',
            type: 'POST',
            data: formData,
            success: function(response) {
                /*res = JSON.parse(response);
                if (res.status == 1) {
                    location.reload();
                } else {
                swal("Error", res.msg, "error");
                }*/
                console.log(commentid,"::::",srno);
                $('#commentreply_'+commentid+' #'+srno).before(response);
                
            },
            error: function(e) {
                swal("Error", e, "error");
            }
    });
    
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>