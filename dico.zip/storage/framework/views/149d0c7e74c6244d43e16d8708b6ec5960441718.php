<title>DICO - Login</title>    
<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .error1{
            position: relative;
            left: 145px;
        }
    </style>
    <body class="login-page">
    <header class="navbar navbar-inverse navbar-fixed-top" role="banner">
        <a data-original-title="Toggle Sidebar" id="leftmenu-trigger" class="tooltips" data-toggle="tooltip" data-placement="right" title=""></a>
        <div class="navbar-header pull-left">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">DICO</a>
        </div>
    </header>
    <div class="verticalcenter">
        <?php echo $__env->make('template.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <form class="common-form" method="POST" action="<?php echo e(url('/forgotPasswordMail')); ?>" id="forgot_form">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label class="text-15">Email Id:</label>
                <input type="hidden" name="usertype" value="0">
                <input id="email" name="email" type="email" placeholder="Enter email address" required autofocus>
                <div id="email_error" class="error1"></div>
            </div>
           
            <div class="form-group">
                <div class="btn-wrap-div">                    
                    <input type="submit" value="Send" class="st-btn loginBtn">
                    <a href="<?php echo e(url('/login')); ?>" class="st-btn loginBtn">Back</a>
                </div>
                
            </div>
        </form>
    </div>
    </body>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>