
<?php $__env->startSection('content'); ?>

    <?php $state = 'disabled'; ?>
    <?php echo Form::open(['method' => 'PUT', 'route' => ['group.update', $groupData->id], 'id' => 'group_users_edit_form']); ?>

    <div id="page-content">
        <div id='wrap'>
            <div id="page-heading">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('group.index')); ?>">Group</a></li>
                    <li class="active">Update Group</li>
                </ol>
                <h1>Update Group</h1>
                <div class="options">
                    <div class="btn-toolbar">
                        <a href="<?php echo e(route('group.index')); ?>" class="btn btn-default">Back</a>
                        <input type="submit" name="save" id="save" class="btn btn-primary" value="Submit">
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="panel panel-midnightblue">

                    <input type="hidden" id="group_id" value="<?php echo e($groupId); ?>">
                    <input type="hidden" id="company_id" value="<?php echo e($groupData->company_id); ?>">
                    
                        
                    
                    <div class="panel-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('err_msg')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('err_msg')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <div class="col-md-6">
                                <label for="group_name">Group name:*</label>
                                <input type="text" name="group_name" id="group_name" class="form-control required"
                                       value="<?php echo e($groupData->group_name); ?>"/>
                            </div>
                            <div class="col-md-6">
                                <label for="group_description"> Group Description:*</label>
                                <textarea name="group_description" id="group_description"
                                          class="form-control"><?php echo e(nl2br($groupData->description)); ?></textarea>
                            </div>
                        </div>
                        <br>

                        <div class="form-group">
                            <div class="col-md-6">
                                <label for="company_listing">Company:* </label>
                                <select name="company_listing" class="form-control required" <?php echo e($state); ?>>
                                    <option value="">Select Company:*</option>
                                    <?php $groupCompanyId = $groupData->company_id; ?>
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($comp->id == $groupCompanyId?'selected':''); ?> value="<?php echo e($comp->id); ?>"><?php echo e($comp->company_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="company_users">Add Users</label>
                                <select name="company_users[]" id="company_users" class="form-control" multiple="multiple">
                                    <?php if($companyEmployee->count() > 0): ?>
                                        <?php $__currentLoopData = $companyEmployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="">All eligible users have been already added to this group.</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="" style="width: 100%">&nbsp;</label>
                                <button id="add_user" class="btn btn-success">Add to group</button>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                        <br>
                        <div class="form-group">
                            <div class="col-md-12 table-responsive">
                                <table class="table table-bordered table-striped" id="group_users_edit_table">
                                <thead>
                                <tr>
                                    <th>#ID</th>
                                    <th>Name</th>
                                    <th>Admin</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>