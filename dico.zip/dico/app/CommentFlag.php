<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentFlag extends Model
{
    //
}
