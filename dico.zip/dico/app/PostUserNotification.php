<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostUserNotification extends Model
{
    //
}
