@include('template.head')

@yield('content')

@include('template.footer')