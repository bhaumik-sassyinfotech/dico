@extends('template.default')
<title>DICO - Dashboard</title>
@section('content')
@endsection