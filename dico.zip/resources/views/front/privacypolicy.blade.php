@extends('front_template.layout')
@section('content')    

<!-- ************* content-Section ********************-->
<div class="content-wrapper">
    <div class="wrap cms-wrapper privacy-wrapper">
        <div class="container">
            <h3 class="page-title">Privacy Policy</h3>
            <div class="privacy-wrap cms-wrap">
                <div class="static-text wow fadeIn">

                    <h3 class="title">Lorem Title</h3>
                    <p>Curabitur ut est a mi fermentum tristique. Aliquam et ante odio. Donec elementum odio eget ex porta,
                        vel laoreet nisl fermentum. Nam risus purus, hendrerit id placerat sit amet, tempor a urna.
                        Maecenas id quam et dolor facilisis pulvinar.
                    </p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <p>
                        Curabitur ut est a mi fermentum tristique. Aliquam et ante odio. Donec elementum odio eget ex porta,
                        vel laoreet nisl fermentum. Nam risus purus,hendrerit id placerat sit amet, tempor a urna. Maecenas id quam et dolor facilisis pulvinar
                    </p>
                    <p>
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.".
                    </p>

                    <h3 class="title">Lorem Title</h3>
                    <p>
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.".
                    </p>

                    <h3 class="title">Lorem Title</h3>
                    <p>Curabitur ut est a mi fermentum tristique. Aliquam et ante odio. Donec elementum odio eget ex porta,
                        vel laoreet nisl fermentum. Nam risus purus, hendrerit id placerat sit amet, tempor a urna.
                        Maecenas id quam et dolor facilisis pulvinar.
                    </p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <p>
                        Curabitur ut est a mi fermentum tristique. Aliquam et ante odio. Donec elementum odio eget ex porta,
                        vel laoreet nisl fermentum. Nam risus purus,hendrerit id placerat sit amet, tempor a urna. Maecenas id quam et dolor facilisis pulvinar
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ************* content-Section close********************-->

@stop
@section('javascript')    
@endsection