<?php 
echo phpinfo();
?>